package cooking.com.whatscooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import cooking.com.whatscooking.entity.User;
import cooking.com.whatscooking.repository.UserRepository;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Register a new user
    @Transactional
    public User registerUser(User user) {
        return userRepository.save(user);
    }

    // Get a user by username
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Get a user by email
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // Get a user by ID
    public User getUserById(Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        return optionalUser.orElse(null);
    }

    // Update user information
    @Transactional
    public User updateUser(Long userId, User userDetails) {
        if (userRepository.existsById(userId)) {
            userDetails.setId(userId);
            return userRepository.save(userDetails);
        }
        return null;
    }

    // Delete a user by ID
    @Transactional
    public boolean deleteUser(Long userId) {
        if (userRepository.existsById(userId)) {
            userRepository.deleteById(userId);
            return true;
        }
        return false;
    }

    // Change user password
    @Transactional
    public User changePassword(Long userId, String newPassword) {
        User user = getUserById(userId);
        if (user != null) {
            user.setPassword(newPassword);
            return userRepository.save(user);
        }
        return null;
    }

	public void setUserRepository(UserRepository userRepository2) {
		// TODO Auto-generated method stub
		
	}
}
