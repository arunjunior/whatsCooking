package cooking.com.whatscooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cooking.com.whatscooking.entity.Recipe;
import cooking.com.whatscooking.repository.RecipeRepository;

@Service
public class RecipeService {

    @Autowired
    private RecipeRepository recipeRepository;

    // Add a new recipe
    public Recipe addRecipe(Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    // Get recipe by ID
    public Recipe getRecipeById(Long recipeId) {
        return recipeRepository.findById(recipeId)
                               .orElseThrow();
    }

    // Update a recipe
    public Recipe updateRecipe(Long recipeId, Recipe recipeDetails) {
        Recipe recipe = recipeRepository.findById(recipeId)
                                        .orElseThrow();
        recipe.setName(recipeDetails.getName());
        recipe.setDescription(recipeDetails.getDescription());
        recipe.setIngredients(recipeDetails.getIngredients());
        recipe.setSteps(recipeDetails.getSteps());
        recipe.setEnabled(recipeDetails.isEnabled());
        return recipeRepository.save(recipe);
    }

    // Delete a recipe
    public void deleteRecipe(Long recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                                        .orElseThrow();
        recipeRepository.delete(recipe);
    }

    // Search recipes by name
    public List<Recipe> searchRecipes(String keyword) {
        return recipeRepository.findByNameContaining(keyword);
    }

    // Enable or disable a recipe
    public Recipe toggleRecipeStatus(Long recipeId, boolean enabled) {
        Recipe recipe = recipeRepository.findById(recipeId)
                                        .orElseThrow();
        recipe.setEnabled(enabled);
        return recipeRepository.save(recipe);
    }

	public void setRecipeRepository(RecipeRepository recipeRepository2) {
		// TODO Auto-generated method stub
		
	}
}
