package cooking.com.whatscooking.repository;

import cooking.com.whatscooking.entity.Recipe;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class RecipeRepositoryTests {

    @Autowired
    private RecipeRepository recipeRepository;

    @BeforeEach
    void setUp() {
        recipeRepository.deleteAll();
    }

    @Test
    void shouldFindRecipesByNameContaining() {
        Recipe recipe1 = new Recipe();
        recipe1.setName("Pasta");
        recipeRepository.save(recipe1);

        Recipe recipe2 = new Recipe();
        recipe2.setName("Pancake");
        recipeRepository.save(recipe2);

        List<Recipe> foundRecipes = recipeRepository.findByNameContaining("Pas");
        assertThat(foundRecipes).hasSize(1).contains(recipe1);
    }
}
