package cooking.com.whatscooking.service;

import cooking.com.whatscooking.entity.User;
import cooking.com.whatscooking.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class UserServiceTests {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void shouldRegisterUser() {
        User user = new User("john_doe", "password", "john@example.com", "John Doe");
        when(userRepository.save(any(User.class))).thenReturn(user);

        User createdUser = userService.registerUser(user);
        assertThat(createdUser).isNotNull();
        assertThat(createdUser.getUsername()).isEqualTo("john_doe");
    }

    @Test
    void shouldGetUserByUsername() {
        User user = new User("john_doe", "password", "john@example.com", "John Doe");
        when(userRepository.findByUsername("john_doe")).thenReturn(user);

        User foundUser = userService.getUserByUsername("john_doe");
        assertThat(foundUser).isNotNull();
        assertThat(foundUser.getUsername()).isEqualTo("john_doe");
    }

    @Test
    void shouldUpdateUser() {
        User existingUser = new User("john_doe", "password", "john@example.com", "John Doe");
        existingUser.setId(1L);

        User updatedUser = new User("john_doe_updated", "newpassword", "john_updated@example.com", "John Doe Updated");
        updatedUser.setId(1L);
        when(userRepository.existsById(1L)).thenReturn(true);
        when(userRepository.save(any(User.class))).thenReturn(updatedUser);

        User result = userService.updateUser(1L, updatedUser);
        assertThat(result).isNotNull();
        assertThat(result.getUsername()).isEqualTo("john_doe_updated");
    }

    @Test
    void shouldDeleteUser() {
        when(userRepository.existsById(1L)).thenReturn(true);

        boolean isDeleted = userService.deleteUser(1L);
        assertThat(isDeleted).isTrue();
        verify(userRepository, times(1)).deleteById(1L);
    }

    @Test
    void shouldChangePassword() {
        User user = new User("john_doe", "oldpassword", "john@example.com", "John Doe");
        user.setId(1L);
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);

        User updatedUser = userService.changePassword(1L, "newpassword");
        assertThat(updatedUser).isNotNull();
        assertThat(updatedUser.getPassword()).isEqualTo("newpassword");
    }
}
