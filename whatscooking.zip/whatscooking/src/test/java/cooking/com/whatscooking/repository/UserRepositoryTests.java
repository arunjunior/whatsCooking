package cooking.com.whatscooking.repository;

import cooking.com.whatscooking.entity.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class UserRepositoryTests {

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void setUp() {
        userRepository.deleteAll();
    }

    @Test
    void shouldFindUserByUsername() {
        User user = new User("john_doe", "password", "john@example.com", "John Doe");
        userRepository.save(user);

        User foundUser = userRepository.findByUsername("john_doe");
        assertThat(foundUser).isNotNull();
        assertThat(foundUser.getUsername()).isEqualTo("john_doe");
    }

    @Test
    void shouldFindUserByEmail() {
        User user = new User("john_doe", "password", "john@example.com", "John Doe");
        userRepository.save(user);

        User foundUser = userRepository.findByEmail("john@example.com");
        assertThat(foundUser).isNotNull();
        assertThat(foundUser.getEmail()).isEqualTo("john@example.com");
    }
}
