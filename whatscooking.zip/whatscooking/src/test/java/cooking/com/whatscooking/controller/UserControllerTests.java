package cooking.com.whatscooking.controller;

import cooking.com.whatscooking.entity.User;
import cooking.com.whatscooking.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@WebMvcTest(UserController.class)
public class UserControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Test
    public void testRegisterUser() throws Exception {
        User user = new User("john_doe", "password", "john@example.com", "John Doe");
        when(userService.registerUser(any(User.class))).thenReturn(user);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/users/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\": \"john_doe\", \"password\": \"password\", \"email\": \"john@example.com\", \"name\": \"John Doe\"}"))
                .andExpect(MockMvcResultMatchers.status().isCreated());
    }

    @Test
    public void testGetUserByUsername() throws Exception {
        User user = new User("john_doe", "password", "john@example.com", "John Doe");
        when(userService.getUserByUsername(any(String.class))).thenReturn(user);

        mockMvc.perform(MockMvcRequestBuilders.get("/api/users/name/john_doe"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
