package cooking.com.whatscooking.service;

import cooking.com.whatscooking.entity.Recipe;
import cooking.com.whatscooking.repository.RecipeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class RecipeServiceTests {

    @InjectMocks
    private RecipeService recipeService;

    @Mock
    private RecipeRepository recipeRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddRecipe() {
        Recipe recipe = new Recipe();
        recipe.setName("Test Recipe");

        when(recipeRepository.save(recipe)).thenReturn(recipe);

        Recipe createdRecipe = recipeService.addRecipe(recipe);

        assertNotNull(createdRecipe);
        assertEquals("Test Recipe", createdRecipe.getName());
    }

    @Test
    void testGetRecipeById() {
        Recipe recipe = new Recipe();
        recipe.setId(1L);
        recipe.setName("Test Recipe");

        when(recipeRepository.findById(1L)).thenReturn(Optional.of(recipe));

        Recipe foundRecipe = recipeService.getRecipeById(1L);

        assertNotNull(foundRecipe);
        assertEquals("Test Recipe", foundRecipe.getName());
    }

    @Test
    void testUpdateRecipe() {
        Recipe existingRecipe = new Recipe();
        existingRecipe.setId(1L);
        existingRecipe.setName("Old Name");

        Recipe updatedRecipe = new Recipe();
        updatedRecipe.setName("Updated Name");

        when(recipeRepository.findById(1L)).thenReturn(Optional.of(existingRecipe));
        when(recipeRepository.save(existingRecipe)).thenReturn(existingRecipe);

        Recipe result = recipeService.updateRecipe(1L, updatedRecipe);

        assertNotNull(result);
        assertEquals("Updated Name", result.getName());
    }

    @Test
    void testDeleteRecipe() {
        Recipe recipe = new Recipe();
        recipe.setId(1L);

        when(recipeRepository.findById(1L)).thenReturn(Optional.of(recipe));
        doNothing().when(recipeRepository).delete(recipe);

        recipeService.deleteRecipe(1L);

        verify(recipeRepository, times(1)).delete(recipe);
    }
}
